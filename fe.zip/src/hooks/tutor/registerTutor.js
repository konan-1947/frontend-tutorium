import { useMutation } from '@tanstack/react-query';

export const useRegisterTutor = () => {
  return useMutation({

    mutationFn: async (formdata) => {
      console.log(formdata);  
      const response = await fetch('/api/tutor/registertutor', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formdata),
      });
   

      const data = await response.json();
    
      if (!response.ok) {
        console.log("Lỗi:", data.error); // In lỗi rõ ràng
        throw new Error(data.message); // Ném lỗi ra ngoài để xử lý tiếp
      }
    
      return data;
    },
    onSuccess: (data) => {
      console.log('Verification successful:', data);
    },
    onError: (error) => {
      console.error('Verification error:', error);
    },
  });
};

export default useRegisterTutor; 